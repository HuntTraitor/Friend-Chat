import { render } from '@testing-library/react'
import Index from '@/pages';

it('Renders', async() => {
  render(<Index />)
})